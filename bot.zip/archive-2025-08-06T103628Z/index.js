// ---- IMPORT ----
import mineflayer from 'mineflayer'
import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'
import config from './config.js'
import logger from './logger/logger.js'

// ---- FIX __dirname và __filename vì ESM không có sẵn ----
const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

// ---- TẠO BOT ----
const botOptions = {
  host: config.host,
  port: config.port,
  username: config.username
}

// Nếu config.version tồn tại và là string hợp lệ thì mới set, tránh gán false
if (typeof config.version === 'string' && config.version.length > 0) {
  botOptions.version = config.version
} else {
  logger.warn('Dang tìm phiên bản server...')
}

const bot = mineflayer.createBot(botOptions)

bot.commands = new Map()
bot.prefix = config.prefix
bot.admins = config.admins

// ---- LOAD EVENTS ----
const eventsPath = path.join(__dirname, 'events')
const eventFiles = fs.readdirSync(eventsPath)

for (const file of eventFiles) {
  if (file.endsWith('.js')) {
    const eventModule = await import(`./events/${file}`)
    eventModule.default(bot)
    logger.success(`✅ Đã load event: ${file}`)
  }
}

// ---- LOAD COMMANDS ----
const cmdPath = path.join(__dirname, 'commands')
const cmdFiles = fs.readdirSync(cmdPath)

for (const file of cmdFiles) {
  if (file.endsWith('.js')) {
    const cmdModule = await import(`./commands/${file}`)
    const cmd = cmdModule.default
    bot.commands.set(cmd.name, cmd)

    if (cmd.alias && Array.isArray(cmd.alias)) {
      for (const alias of cmd.alias) {
        bot.commands.set(alias, cmd)
        logger.success(`→ Alias thêm: ${alias} cho lệnh ${cmd.name}`)
      }
    }

    logger.success(`✅ Đã load lệnh: ${cmd.name}`)
  }
}

// ---- SỰ KIỆN LOGIN & ERROR ----
bot.once('login', () => {
  logger.info(`🤖 Bot đã login vô server: ${config.host}:${config.port}`)
})

bot.on('error', (err) => logger.error('❌ Bot lỗi:', err))

bot.on('end', () => {
  logger.warn('⛔ Bot đã disconnect khỏi server')
})

bot.on('kicked', (reason) => {  console.log(JSON.stringify(reason, null, 2));

});

// ---- SỰ KIỆN SPAWN ----
bot.once('spawn', () => {
  logger.success('✅ Bot đã spawn trong thế giới')
})

// ---- TRỌNG LỰC - PHYSICS TICK ----
bot.on('physicsTick', () => {
  if (!bot.entity.onGround) {
    bot.clearControlStates?.() // xài nếu có
    bot.setControlState('jump', false)
    bot.setControlState('sneak', false)
    bot.setControlState('forward', false)
    bot.setControlState('back', false)
    bot.setControlState('left', false)
    bot.setControlState('right', false)
  }
})