export default {
  name: 'ping',
  description: 'Check ping bot',
  adminOnly: true,

  execute(bot, username, args) {
    bot.chat(`/minecraft:w @${username} ping: ${bot.player.ping}ms`)
  }
}