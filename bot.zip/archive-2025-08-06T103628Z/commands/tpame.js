export default {
  name: 'tpa',
  description: 'Bot gửi lệnh /tpa đến m',
  adminOnly: true, // Cho chắc, chỉ admin gọi được

  execute(bot, username, args) {
    const subcmd = args[0]?.toLowerCase()

    if (subcmd !== 'me') {
      return bot.chat(`/w ${username} xài như này nè: !tpa me`)
    }

    bot.chat(`/tpa ${username}`)
    bot.chat(`/w ${username} gửi tpa rồi nhen, accept lẹ đi`)
  }
}