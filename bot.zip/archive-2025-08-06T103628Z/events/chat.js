import chalk from 'chalk'
import config from '../config.js'

export default (bot) => {
  bot.on('chat', async (username, message) => {
    if (username === bot.username) return

    if (message.startsWith(bot.prefix)) {
      logCMD('chat', username, message)
      handleCommand(bot, username, message)
    }
  })

  bot.on('messagestr', (message) => {
    if (!message.startsWith(bot.prefix)) return

    const match = message.match(/^<(.+?)> /)
    if (!match) return

    const username = match[1]
    if (username === bot.username) return

    logCMD('msgstr', username, message)
    handleCommand(bot, username, message)
  })

  bot.on('whisper', (username, message) => {
    if (username === bot.username) return
    if (!message.startsWith(bot.prefix)) return

    logCMD('whisper', username, message)
    handleCommand(bot, username, message)
  })
}

// ✅ Function log command xịn xò
function logCMD(type, username, message) {
  const tagColor = {
    chat: chalk.bgBlue.white.bold,
    msgstr: chalk.bgGreen.black.bold,
    whisper: chalk.bgMagenta.white.bold
  }[type] || chalk.bgGray.white.bold

  console.log(`${tagColor(` CMD/${type} `)} ${chalk.yellow(username)}: ${chalk.cyan(message)}`)
}

// ✅ Function xử lý command
function handleCommand(bot, username, message) {
  if (!message.startsWith(bot.prefix)) return

  const args = message.slice(bot.prefix.length).trim().split(/ +/)
  const cmdName = args.shift().toLowerCase()
  const cmd = bot.commands.get(cmdName)

  if (!cmd) {
    bot.chat(`/w ${username} ❌ Không tồn tại lệnh "${cmdName}" đâu cu`)
    return
  }

  if ((cmd.adminOnly ?? false) && !bot.admins.includes(username)) {
    bot.chat(`/w ${username} m nghĩ m là ai vcl? Lệnh này cho admin dùng thôi`)
    return
  }

  try {
    cmd.execute(bot, username, args)
  } catch (err) {
    bot.chat(`/w ${username} Có lỗi xảy ra khi xử lý lệnh rồi bro :((`)
    console.error(chalk.red(`[ERROR] Lỗi khi chạy lệnh "${cmdName}":`), err)
  }
}