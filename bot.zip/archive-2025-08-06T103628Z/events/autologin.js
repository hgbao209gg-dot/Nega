import config from '../config.js'
import logger from '../logger/logger.js'

export default (bot) => {
  const lower = (text) => text.toLowerCase()

  let isRegistered = false
  let isLoggedIn = false

  bot.on('messagestr', (message) => {
    const msg = lower(message)

    // Nếu bot đã đăng nhập thì khỏi check tiếp, tránh spam
    if (isLoggedIn) return

    if (!isRegistered && (msg.includes('/register') || msg.includes('đăng ký') || msg.includes('register'))) {
      const cmd = `/register ${config.password} ${config.password}`
      bot.chat(cmd)
      logger.info(`[AUTO] Gửi lệnh đăng ký: ${cmd}`)
      isRegistered = true
    } else if (!isLoggedIn && (msg.includes('/login') || msg.includes('đăng nhập') || msg.includes('login'))) {
      const cmd = `/login ${config.password}`
      bot.chat(cmd)
      logger.info(`[AUTO] Gửi lệnh đăng nhập: ${cmd}`)
      isLoggedIn = true
    }
  })

  bot.on('end', () => {
    isRegistered = false
    isLoggedIn = false
  })
}