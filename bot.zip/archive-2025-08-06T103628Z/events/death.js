export default (bot) => {
  let lastAttacker = null

  // Bắt sự kiện bị đánh
  bot.on('entityHurt', (entity) => {
    if (entity !== bot.entity) return

    const attacker = getNearestAttacker()
    if (attacker) lastAttacker = attacker
  })

  // Khi chết
  bot.on('death', () => {
    if (lastAttacker) {
      const name = lastAttacker.username || lastAttacker.name || '???'
      const heldItem = lastAttacker.heldItem

      let weaponInfo = 'tay không'

      if (heldItem) {
        const itemName = heldItem.displayName || heldItem.name
        const enchants = heldItem.enchants?.map(e => `${e.name} ${e.lvl}`) || []
        weaponInfo = `${itemName}${enchants.length > 0 ? ` (${enchants.join(', ')})` : ''}`
      }

      console.log(`[LOG] Bot bị ${name} giết bằng ${weaponInfo}`)
    } else {
      console.log(`[LOG] Bot chết mà không rõ ai giết`)
    }

    // Reset sau khi chết
    lastAttacker = null

    // Respawn sau 5s
    setTimeout(() => {
      if (bot.player) {
        bot._client.write('client_command', { payload: 0 })
      }
    }, 5000)
  })

  function getNearestAttacker() {
    let attacker = null
    let minDist = Infinity

    for (const id in bot.entities) {
      const entity = bot.entities[id]
      if (!entity || !entity.username || !entity.heldItem) continue

      const dist = bot.entity.position.distanceTo(entity.position)
      if (dist < 6 && dist < minDist) {
        minDist = dist
        attacker = entity
      }
    }

    return attacker
  }
}