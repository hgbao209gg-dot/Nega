export default {
  host: '16.hcm04.asakacloud.vn',
  port: 25565,
  version: '1.20.4',
  username: 'Cyka_blyat',
  prefix: '!',
  admins: ['Hgbao209'],
  password: '19/8/2009',
}
